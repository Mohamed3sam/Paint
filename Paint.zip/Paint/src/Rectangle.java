import java.awt.Color;
import java.awt.geom.Rectangle2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
class rectangle extends shapes
{
    public rectangle(Rectangle2D r,Color l,int size,float[] vertx,float[] verty)
    {
        o=r;
        c=l;
        this.size=size;
        this.vertx=vertx;
        this.verty=verty;
    }
}

// draw Rectangle2D.Double
//g2.draw(new Rectangle2D.Double(x, y,rectwidth,rectheight));
