
import java.awt.Color;
import java.awt.geom.Ellipse2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
class Ellipse extends shapes
{
    public Ellipse(Ellipse2D r,Color l,int size,float x1,float y1,float width,float height)
    {
        o=r;
        c=l;
        this.size=size;
        this.x1=x1;
        this.y1=y1;
        this.width=width;
        this.height=height;
    }
}
// fill Ellipse2D.Double
//redtowhite = new GradientPaint(0,0,color.RED,100, 0,color.WHITE);
//g2.setPaint(redtowhite);
//g2.fill (new Ellipse2D.Double(0, 0, 100, 50));
