
import java.awt.Color;
import java.awt.geom.Arc2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
public class Arc extends shapes {

    public Arc(Arc2D i,Color j,int size)
    {
        o=i;
        c=j;
        this.size=size;
    }
} 