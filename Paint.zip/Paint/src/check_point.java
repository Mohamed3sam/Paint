/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
public class check_point {

    public static boolean point_check_2(int nvert, float []vertx, float []verty, float testx, float testy)
    {
        int i, j;
        boolean c = false;
        for (i = 0, j = nvert-1; i < nvert; j = i++) 
        {
            if ( ((verty[i]>testy) != (verty[j]>testy)) &&
                (testx < (vertx[j]-vertx[i]) * (testy-verty[i]) / (verty[j]-verty[i]) + vertx[i]) )
            {
                    c=!c;
            }
        }
            return c;
    }
    public static boolean point_check(int nvert, float []vertx, float []verty, float testx, float testy)
    {
        boolean c = false;
            if ((testx>=vertx[0])&&(testx<=vertx[1])&&(testy>=verty[0])&&(testy<=verty[2]))
            {
                    c=!c;
            }
            return c;
    }
}
