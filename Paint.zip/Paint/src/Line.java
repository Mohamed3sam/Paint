
import java.awt.Color;
import java.awt.geom.Line2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
class Line extends shapes
{
    public Line(Line2D l,Color x,int size)
    {
        o=l;
        c=x;
        this.size=size;
    }
}
// draw Line2D.Double
//g2.draw(new Line2D.Double(x1, y1, x2, y2));
//Line2D.Float(float X1, float Y1, float X2, float Y2)
//Line2D.Float(Point2D p1, Point2D p2)
