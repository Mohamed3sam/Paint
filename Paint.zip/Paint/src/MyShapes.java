
import java.awt.Color;
import java.awt.Graphics;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
public class MyShapes
{
    public shapes[] drawnshapes;
    public int indexer;
    public MyShapes()
    {
        drawnshapes=new shapes[500000];
        indexer=0;
    }
    public void addshape(shapes s)
    {
        drawnshapes[indexer++]=s;
    }
    public void removelastshape()
    {
        indexer--;
    }
    public void getlastshape()
    {
        indexer++;
    }
    public shapes getshape()
    {
        return drawnshapes[--indexer];
    }
    public void deleteshape(int value)
    {
        for(int i=value;i<indexer;i++)
        {
            drawnshapes[i]=drawnshapes[i+1];
        }
        indexer--;
    }
}

