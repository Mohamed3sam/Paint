/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 * @param <t>
 */
public class stack<t> {
    public t[] shapes;
    public int indexer;
    public stack()
    {
        shapes=(t[])new Object[100];
        indexer=0;
    }
    public void push(t st)
    {
        shapes[indexer++]=st;
    }
    public t pop()
    {
        return shapes[--indexer];
    }
    public t see()
    {
        int buffer=indexer-1;
        return shapes[buffer];
    }
}
