import java.awt.Color;
import java.awt.Shape;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Mohamed Essam
 */
public class shapes 
{
    public Shape o;
    public Color c;
    public int size;
    public float x1;
    public float y1;
    public float width;
    public float height;
    public float[] vertx=new float[4];
    public float[] verty=new float[4];
    public float[] px=new float[3];
    public float[] py=new float[3];
   public shapes()
    {
        
    }
}
