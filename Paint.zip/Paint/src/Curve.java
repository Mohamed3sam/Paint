
import java.awt.Color;
import java.awt.geom.QuadCurve2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
public class Curve extends shapes {

    public Curve(QuadCurve2D p,Color k,int size)
    {
        o=p;
        c=k;
        this.size=size;
    }
} 
// create new QuadCurve2D.Float
//QuadCurve2D q = new QuadCurve2D.Float();
// draw QuadCurve2D.Float with set coordinates
//q.setCurve(x1, y1, ctrlx, ctrly, x2, y2);
//g2.draw(q);
