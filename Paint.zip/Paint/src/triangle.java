
import java.awt.Color;
import java.awt.Polygon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
public class triangle extends shapes {
    public triangle(Polygon p,Color l,int size,float[] px,float[] py)
    {
        this.o=p;
        c=l;
        this.size=size;
        this.px=px;
        this.py=py;
    }
}
