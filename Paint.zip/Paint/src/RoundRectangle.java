import java.awt.Color;
import java.awt.geom.RoundRectangle2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed Essam
 */
public class RoundRectangle extends shapes {
    
    public RoundRectangle(RoundRectangle2D y,Color s)
    {
        o=y;
        c=s;
    }
}
   
// draw RoundRectangle2D.Double
//g2.draw(new RoundRectangle2D.Double(x, y,rectwidth,rectheight,10, 10));

//To set the location, size, and arcs of a RoundRectangle2D object,
//use the method setRoundRect(double a, double y, double w, double h, double arcWidth, double arcHeight). For example:

